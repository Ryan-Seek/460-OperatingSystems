#include "ucode.c"

int main()
{
  ubody("one");
}
 
